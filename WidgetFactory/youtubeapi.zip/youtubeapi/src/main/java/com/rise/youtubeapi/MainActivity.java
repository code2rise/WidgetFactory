package com.rise.youtubeapi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btnGetVideos = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnGetVideos = (Button) findViewById(R.id.btn_get_videos);
        btnGetVideos.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

//        new GetChannelVideosTask().execute();

        new Thread(new Runnable() {
            @Override
            public void run() {
                new Search().getVideos();
            }
        }).start();
    }
}
