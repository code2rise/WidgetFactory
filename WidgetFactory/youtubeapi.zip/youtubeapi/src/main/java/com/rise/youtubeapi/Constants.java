package com.rise.youtubeapi;

/**
 * Created by RupeshCHAVAN on 30-01-2017.
 */

public class Constants {
    static final String YOUTUBE_API_KEY = "AIzaSyDCApmfQ1xl_dU_CneFBfE5A3TKIiPM82U";
    static final String CHANNEL_ID = "UCFHhFwEdsLs2wuvh1YdChHw";

    public static final int WS_TIMEOUT = 1000 * 30;//Time in milli
    public static final int WS_READ_TIMEOUT = 1000 * 30;//Time in milli
}
